package fbtest;


import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;



@CucumberOptions(
        features = {"src/test/java/fbtest/fbuser.feature"},
        glue= {"fbtest"},
        tags= "@users"
        
)
@RunWith(Cucumber.class)
public class TestRunner
{

}
