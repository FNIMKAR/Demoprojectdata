package fbtest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Userssteps
{
	 ChromeDriver cd;
    @Given("^user is on login page$")
    public void user_is_on_login_page() throws Throwable
    {
       cd = new ChromeDriver(); // open browser
		
		cd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
      
        cd.manage().window().maximize();  //maximize screen
        
        cd.get("http://www.facebook.com");  //opening url
        
        cd.findElement(By.xpath("//a[text()='English (UK)']")).click();

    }

    @When("^enter valid user name and password and click$")
    public void enter_valid_user_name_and_password_and_click() throws Throwable 
    {
    	cd.findElement(By.id("email")).sendKeys("falguninimkar@gmail.com");  //send data to element by id      
        cd.findElement(By.id("pass")).sendKeys("falguni13");     
    }

    @Then("^homepage is displayed$")
    public void homepage_is_displayed() throws Throwable
    {
    	cd.findElement(By.name("login")).click();
    }

    @And("^close browser$")
    public void close_browser() throws Throwable {
        cd.quit();
    }

}
