
public class Prog3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str="kf55&k#flk$%oo90";

        System.out.println("caracter types are : ");
        
		for (char ch:str.toCharArray()) {

        if((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {

             System.out.println(ch + " is A ALPHABET.");

        } else if(ch >= '0' && ch <= '9') {

             System.out.println(ch + " is A DIGIT.");

        } else {

             System.out.println(ch + " is A SPECIAL CHARACTER.");
        }
        }
	}

}
