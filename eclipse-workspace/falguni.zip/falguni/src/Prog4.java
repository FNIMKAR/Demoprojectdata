import java.util.Arrays; 
public class Prog4 {

	public static void main(String[] args) {
		
		int [] array = new int [] {10,4,8,9,23,45,22,14,30,89};  
		//invoking sort() method of the Arrays class  
		Arrays.sort(array); 
		
		System.out.println("Elements of array sorted in ascending order: ");  
		  
		for (int i = 0; i < array.length; i++)   
		{       
		System.out.println(array[i]);   
		}   

	}

}
