package falguni;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stu
			
		String str;
		str = "javaprogramming";
		int cnt = 0;
		
		System.out.println("Vowels are ");
		for(int i = 0; i < str.length(); i++)
		{
			if (str.charAt(i) == 'a' || str.charAt(i) == 'e' || str.charAt(i) == 'i' || str.charAt(i) == 'o' || str.charAt(i) == 'u')
			{			    
			    System.out.print(str.charAt(i) + " ");
				cnt++;
			}
			
				
		}
		System.out.println();
		System.out.println("Total Vowels " + cnt);
	
	
	
	}
}