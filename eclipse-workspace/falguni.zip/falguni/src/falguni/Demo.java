package falguni;

//import jdk.internal.misc.FileSystemOption;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x,y;
		x=5;
		y=8;
	
		
		System.out.println(Math.pow(x, y));
		
		String str="My first work";  
		System.out.println("string length is: "+str.length()); 
	    System.out.println(str.substring(0,4)); 
		System.out.println(str.toUpperCase());
	    System.out.println(str.substring(5,8));
		System.out.println(str.replace("work","program"));
		System.out.println(str.indexOf("first"));
		System.out.println(str.contains("work"));
		System.out.println(str.charAt(2));
		//if statements
		if(x+y < 20) {    
			System.out.println("x + y is greater than 20"); 
		}
		// smallest no
		int a=45, b=20, c=50;
		if(a <= b && a <= c)
		           System.out.println(a+"is the smallest");
		else if(b <= a && b <= c)
			System.out.println(b +"is the smallest");
		else
			System.out.println(c+"is the smallest");
		
		
		//leap year
        int year = 1998;
        if (year % 400 == 0) {
            System.out.println(year + " is a leap year.");
        } else if (year % 100 == 0) {
            System.out.println(year + " is not a leap year.");
        } else if (year % 4 == 0) {
            System.out.println(year + " is a leap year.");
        } else {
            System.out.println(year + " is not a leap year.");
        }
        
        //take month number
        int month = 5;
        if ((month == 12)||(month == 1)||(month == 2))
        	System.out.println("Its a winter");
        else if ((month == 3)||(month == 4)||(month == 5))
        	System.out.println("Its a summer");
        else if ((month == 6)||(month == 7)||(month == 8))
        	System.out.println("Its a rainy");
        else
        	System.out.println("Its a spring");
        
        //take score of a student
        
        int score = 78;
        if (score>= 80)
        	System.out.println("grade A");
        else if (score>= 60)
        	System.out.println("Grade B");
        else if (score >=50)
        	System.out.println("Grade C ");
        else
        	System.out.println("FAILED");
        
        
       //switch case statement
        
        int season = 5;
        switch(season)
        {
        case 12:
        case 1:
        case 2:
        System.out.println("Its a winter");
        break;
        
        case 3:
        case 4:
        case 5:
        System.out.println("Its a summer");
        break;
        
        
	    case 6:
        case 7:
        case 8:
        System.out.println("Its a rainy");
        break;
		default:
		System.out.println("not a valid season");
        }
        
        //while
        
        int i=1;
        		while(i<=10)
        {
        	System.out.println(i);
        	i++;
        }
        //string while
        		
        		String str="Falguni";
        		int n=str.length()-1;
        		
        		
    }


}

