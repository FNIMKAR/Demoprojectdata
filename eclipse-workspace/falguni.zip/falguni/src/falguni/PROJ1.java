/**
 * 
 */
package falguni;

import java.lang.runtime.ObjectMethods;

//import jdk.internal.misc.FileSystemOption;


public class PROJ1 extends ObjectMethods {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int x,y;
		x=5;
		y=5;
		System.out.println(Math.pow(x, y));
		
		String str="My first work";  
		System.out.println("string length is: "+str.length()); 
	    System.out.println(str.substring(0,4)); 
		System.out.println(str.toUpperCase());
	    System.out.println(str.substring(5,8));
		
		
		
		// TODO Auto-generated method stub

	}

}
