
public class Proj2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="fjskd9845kdsjf8349dkfjs";
		System.out.println("Number find in the string:");
		for (char ch:str.toCharArray()) {
			if (Character.isDigit(ch)) {
				System.out.println(ch+"");
			}
		}
	}

}
