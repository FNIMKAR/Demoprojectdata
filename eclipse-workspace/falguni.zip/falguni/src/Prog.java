
public class Prog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str= "javaprogramming";
		System.out.println("Alternate character string:");
		char [] ch = str.toCharArray();
		for (int i=0; i<ch.length; i=i+2)
		{
			ch[i]= Character.toUpperCase(ch[i]);
		}
		System.out.println(ch);
			
	}

}
