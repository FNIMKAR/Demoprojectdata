package P1;
import java.util.Scanner;

class Vehi
{
	String brand,name,type;
	
	Vehi()
	{
		brand = "";
		name = "";
		type = "";
	}
	
	Scanner sc = new Scanner(System.in);
	
	public void get()
	{
		System.out.println("Enter Details");
		brand = sc.next();
		name = sc.next();
		type = sc.next();
	}
	
	public void Display()
	{
		System.out.println("Details are: " + brand + " " + name + " " + type);
	}
	

}


public class Vehicle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Vehi v = new Vehi();     //constructor call
       
       v.get();
       v.Display();
	}

}