//public class Emp
//{
  // private String empId,empName;
   //private int sal;

   //setters,getter methods
//}
//=====================
//public class EmpList
//{
  // List<Emp> l1=new ArrayList<Emp>();
   
	//......read 5 emp details and store in List
//......read the emp details based on index
//}

package P1;

public class Emp {
	private String empId,empName;
	private int sal;
	
	 Emp(String empId,String empName, int sal)
	   { 
	     this.empId = empId; 
	     this.empName =empName ; 
	     this.sal = sal; 
	   } 
	
	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getSal() {
		return sal;
	}

	public void setSal(int sal) {
		this.sal = sal;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
