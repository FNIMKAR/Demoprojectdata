package P1;
/*
 * ArrayList  to store few names

read index value from the user and get the value in the given index from ArrayList.
if index is outof the range,,, handle the Exception.
 */
import java.util.*;
public class Arraylist {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> lst = new ArrayList<String>();
		Scanner sc = new Scanner(System.in);
		lst.add("nikita");
		lst.add("ekta");
		lst.add("do");
		lst.add("neha");
		lst.add("pihu");
		System.out.println("Enter the index number:");
		
		int n;
		n = sc.nextInt();
		if(n > lst.size())
		{
			System.out.println("Out of Bound");
		}
		else
		{
			System.out.println(lst.get(n));
		}


	}

}
	
	


