package P1;

/*
 * public class Emp
{
   private String empId,empName;
   private int sal;

   setters,getter methods

}
=====================
public class EmpList
{
   List<Emp> l1=new ArrayList<Emp>();
   
	......read 5 emp details and store in List

	......read the emp details based on index
}
 */

import java.util.ArrayList;
import java.util.Scanner;

public class EmpList 
{	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		EmpList el1 = new EmpList();
		
		Scanner sc = new Scanner(System.in);
	    String eid,ename;
	    int esal;
	    ArrayList<Emp> lst = new ArrayList<Emp>();
		//Scanner sc = new Scanner(System.in);
		
		for (int i = 0 ; i < 5; i++)
		{
			//System.out.println("Employee " + i+1 + "Details");
			System.out.println("Enter Employee id");
			eid = sc.next();
						
			System.out.println("Enter Employee name");
			ename = sc.next();
			//lst.add(ename);
			
			System.out.println("Enter Employee salary");
			esal = sc.nextInt();
			//lst.add(esal);
			
			Emp e1 = new Emp();
			
			e1.setEmpId(eid);
			e1.setEmpName(ename);
			e1.setSal(esal);
			
			lst.add(e1);
				
			
		}
		
		
		
		System.out.println("Employee Details are" + lst);
		
		

	}

}