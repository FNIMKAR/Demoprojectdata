
package P1;
import java.util.*;
import java.util.Scanner;
import java.lang.*;

//Create a class ArrayEx
//     Write method getPrices() and in the method
//             read input from user what is the size of array.
//             write loop to read the number of prices and store in array, while input if the input value mismatch
//		handle the Exception "InputMismatchException"
//	
//              After storing values in the array, read the index value as input from the user and get the value from array
//		and display, 
//              here also handle the exception  ArrayIndexOutOfBoundsException / InputMismatchException


public class ArrayEx {
	
	private int size,pos;
	
	
	Scanner sc = new Scanner(System.in);
	
	public void getPrices()
	{
		System.out.println("How many price do yo wnat to enter: ");
		size = sc.nextInt();
		
		float price[] = new float[size];
		try 
		{
		    System.out.println("Enter Values for array: ");
			for (int i = 0; i < size; i++)
			{
			    price[i] = sc.nextFloat();
			}
		}
		catch (InputMismatchException e)
		{
		   System.out.println("Please enter valid price");
		}
		
		//print prices
		System.out.println("Product prices are: ");
		
		for (int i = 0; i < size; i++)
		{
		    System.out.println(price[i]);
		}
		
		
		//particular index
		try
		{
			System.out.println("Enter position to view price:");
			pos = sc.nextInt();
		
			System.out.println(price[pos]);
		}
		catch (ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Array Index out of range");
		}
		catch (InputMismatchException e)
		{
			System.out.println("Plaese enter number only");
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayEx ar = new ArrayEx();
		
		ar.getPrices();
	}

}