package P1;


import java.util.Scanner;

//Create a class Student
//variables: name, marks to store 4 subjects scores.
//write a method to calculate Grade based on scores and avg, and return GradeA/GradeB../Fail


class Students
{
	String name;
	int marks[] = new int[4];
	int sum = 0;
	int avg;
	//String grade;
	
	Scanner sc = new Scanner(System.in);
	
	public void get()
	{
		System.out.println("Enter Student Name: ");
		name = sc.next();
		
		System.out.println("Enter Marks of 4 Subject: ");
		for (int i = 0; i < 4; i++)
		{
			if (marks[i] <= 100)			{
				marks[i] = sc.nextInt();
				sum = sum + marks[i];
			}
			else				
				System.out.println("Please enter valid marks");
		}	
	}
	
	public void Display()
	{
		System.out.println("Name: " + name);
		avg = sum/4;
		System.out.println("Average: " + avg);
		
		if (avg >= 75 && avg <= 100)
			System.out.println("Grade A");
		
		else if (avg >= 60 && avg <= 74 )
			System.out.println("Grade B");
		
		else if (avg >= 50 && avg <= 59)
			System.out.println("Grade C");
		
		else if (avg >= 0 && avg <= 49)
			System.out.println("Fail");
		
		else 
			System.out.println("Invalid Marks");

		
	}
}


public class Student {

	public static void main(String[] args) {
       Students s = new Students();
       
       s.get();
       s.Display();
	}

}