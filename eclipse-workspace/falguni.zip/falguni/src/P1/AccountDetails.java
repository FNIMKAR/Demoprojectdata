package P1;

public class AccountDetails {
	public void openaccount()
	{
		int accid,bal;
		String acctype;
		Scanner sc = new Scanner(System.in);
		
		public static void main(String[] args) {
	       try
	       {
	    	   System.out.println("Enter AccountId");
		       accid = sc.nextint();  // Read user input
		       System.out.println("Enter AccountType");
		       acctype=sc.nextLine();
		       System.out.println("Enter Balance");
		       bal=sc.nextInt();
		       
		       if(bal<0)
		    	   throw new exception();
		       Account act = new account(ID,type,bal);
		       System.out.println(act);
		       System.out.println("enter amount for withdraw: ");
		       int wamt=sc.nextInt();
		       act.withdraw("wamt");
		       System.out.println(act);
		       
	       }
	       catch(Exception e) {
	    	   System.out.println("not a valid input");
	    	 }
	       finally {
	    	   sc.close();
	       }
}
	}