package P1;

import java.util.Scanner;

class Employees
{
	private String name,desg;
	private float sal;
		
	Scanner sc = new Scanner(System.in);
	
	public void setEmpName(String newName)
	{
		//System.out.println("Enter Name");
		this.name = newName;
	}
	
	public void setEmpDesg(String newDesg)
	{
		//System.out.println("Enter Designation");
		this.desg = newDesg;
	}
	
	
	public void setEmpSal(float newSal)
	{
		//System.out.println("Enter Salary");
		this.sal = newSal;
	}
	
	
	public String getEmpName()
	{
		//System.out.print("Name: ");
		return this.name;
	}
	
	public String getEmpDesg()
	{
		//System.out.print("Designation: ");
		return this.desg;
	}
	
	public Float getEmpSal()
	{
		//System.out.print("Salary: ");
		return this.sal;
	}
}
public class Employee {
public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employees e = new Employees();
		
		e.setEmpName("Falguni");
		e.setEmpDesg("Level 1");
		e.setEmpSal(25000);
		System.out.println("Name: " + e.getEmpName());
		System.out.println("Designation: " + e.getEmpDesg());
		System.out.println("Salary: "+ e.getEmpSal());

	}

}

