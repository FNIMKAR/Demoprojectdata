

	import java.util.Scanner;

	public class New
	{
	    public static void main(String[] args)
	    {
	        Scanner input = new Scanner( System.in );
	        String yourSentence="";
	        String[] tokens;

	        do
	        {
	            System.out.print("Enter your words here: ");
	            yourSentence = input.nextLine();

	            if( yourSentence.startsWith("a") || yourSentence.startsWith("e") || yourSentence.startsWith("i") ||
	                yourSentence.startsWith("o") || yourSentence.startsWith("u"))
	            {
	                System.out.print(yourSentence+ "a");
	            }
	            else
	            {
	                System.out.print(yourSentence.substring(1)+yourSentence.substring(0,1)+"a");
	            }   
	        }

	        while(!yourSentence.equals("quit"));
	    }
	}
